#pragma once

#include <memory>
#include <string>
#include <vector>
#include <map>

#include "MaintainBeneficiaryHandler.hpp"

namespace Domain::Banking
{
	
	
  class Beneficiaries : public Domain::Banking::MaintainBeneficiaryHandler
  {
    public:
      // Constructors
      using MaintainBeneficiaryHandler::MaintainBeneficiaryHandler;  // inherit constructors
	  

      // Operations
	  std::map<std::string, std::vector<std::string>> getBeneficiary() override;

     ~Beneficiaries() noexcept override;
  }; // class Beneficiaries


  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline Beneficiaries::~Beneficiaries() noexcept
  {}
  // std::map<std::string, std::vector<std::string>> Beneficiaries;
    
  inline std::map<std::string, std::vector<std::string>> Beneficiaries::getBeneficiary()
  {
	  std::map<std::string, std::vector<std::string>> Assign;
	  Assign[""] = {{" "}, {" "}, {" "}};
    return Assign;
  }


}  // namespace Domain::Library
