#pragma once

#include <memory>
#include <string>
#include <vector>


#include "Session.hpp"


namespace Domain::Banking
{
  class ClerkSession : public Domain::Banking::SessionHandler
  {
    public:
      using SessionHandler::SessionHandler;  // inherit constructors

      // Operations
      std::vector<std::string> getCommands() override;  // retrieves the list of actions (commands)
	  


      // Destructor
      // Pure virtual destructor helps force the class to be abstract, but must still be implemented
     ~ClerkSession() noexcept override;
  }; // class InstructorSession





  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline ClerkSession::~ClerkSession() noexcept
  {}


  inline std::vector<std::string> ClerkSession::getCommands()
  {
    return { "Deposit Money", "Open Account", "Close Account","Edit Account","Pay Tax", "Check Credit Score" };
  }

} // namespace Domain::Banking
