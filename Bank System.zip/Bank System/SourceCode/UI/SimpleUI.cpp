#include <iomanip>                                                                    // setw()
#include <iostream>                                                                   // streamsize
#include <limits>                                                                     // numeric_limits
#include <memory>                                                                     // unique_ptr, make_unique<>()
#include <string>                                                                     // string, getline()
#include <vector>
#include <fstream>

#include "Domain/AccountManagement/UserAccounts.hpp"                                  // Include for now - will replace next increment
#include "../Domain/Banking/BankAccounts.hpp"                                                   // Include for now - will replace next increment
#include "../Domain/Banking/Session.hpp"

#include "../TechnicalServices/Logging/LoggerHandler.hpp"
#include "../TechnicalServices/Logging/SimpleLogger.hpp"                                 // Include for now - will replace next increment
#include "../TechnicalServices/Persistence/SimpleDB.hpp"                                 // Include for now - will replace next increment
#include "SimpleUI.hpp"
#include "../../readfile.cpp"

namespace UI
{
	// Default constructor
	SimpleUI::SimpleUI()
		: _accounts(std::make_unique<Domain::AccountManagement::UserAccounts>()),   // will replace these factory calls with abstract factory calls in the next increment
		_bookHandler(std::make_unique<Domain::Banking::BankAccounts>()),   // will replace these factory calls with abstract factory calls in the next increment
		_loggerPtr(std::make_unique<TechnicalServices::Logging::SimpleLogger>()),   // will replace these factory calls with abstract factory calls in the next increment
		_persistentData(std::make_unique<TechnicalServices::Persistence::SimpleDB>())    // will replace these factory calls with abstract factory calls in the next increment
	{
		_logger << "Simple UI being used and has been successfully initialized";
	}


	// Destructor
	SimpleUI::~SimpleUI() noexcept
	{
		_logger << "Simple UI shutdown successfully";
	}



	// Operations
	void SimpleUI::launch()
	{
		// 1) Fetch Role legal value list

		std::vector<std::string> roleLegalValues = _persistentData->findRoles();
		std::string selectedRole;
		std::string selectedCommand;
		std::string username;
		std::string accountidentity;

		// 2) Present login screen to user and get username, password, and valid role
		do
		{
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

			std::string userName;
			std::cout << "  name: ";
			std::getline(std::cin, userName);

			std::string passPhrase;
			std::cout << "  pass phrase: ";
			std::getline(std::cin, passPhrase);

			unsigned menuSelection;
			do
			{
				for (unsigned i = 0; i != roleLegalValues.size(); ++i)   std::cout << std::setw(2) << i << " - " << roleLegalValues[i] << '\n';
				std::cout << "  role (0-" << roleLegalValues.size() - 1 << "): ";
				std::cin >> menuSelection;
			} while (menuSelection >= roleLegalValues.size());

			selectedRole = roleLegalValues[menuSelection];
			username = userName;


			// 3) Validate user is authorized for this role
			if (_accounts->isAuthenticated({ userName, passPhrase, {selectedRole} }))
			{
				_logger << "Login Successful for \"" + userName + "\" as role \"" + selectedRole + "\"";
				break;
			}

			std::cout << "** Login failed\n";
			_logger << "Login failure for \"" + userName + "\" as role \"" + selectedRole + "\"";

		} while (true);



		// 4) Fetch functionality options for this role
		std::unique_ptr<Domain::Banking::SessionHandler> sessionControl = Domain::Banking::SessionHandler::createSession(selectedRole);

		std::vector<std::string> commands = sessionControl->getCommands();
		unsigned totalNumberOfCommands = commands.size();
		unsigned menuSelection;
		do
		{
			for (unsigned i = 0; i != commands.size(); ++i)   std::cout << std::setw(2) << i << " - " << commands[i] << '\n';
			std::cout << "  role (0-" << commands.size() - 1 << "): ";
			std::cin >> menuSelection;
		} while (menuSelection >= totalNumberOfCommands);

		selectedCommand = commands[menuSelection];
		_logger << "Selected command \"" + selectedCommand + "\" chosen";



		// 4) Fetch functionality options for this role
		std::unique_ptr<Domain::Banking::MaintainBankAccountHandler> sessionControlBankAccount = Domain::Banking::MaintainBankAccountHandler::selectCommand(selectedCommand);

		std::vector<std::vector<std::string>> bankAccount = sessionControlBankAccount->getBankAccounts();
		std::map<std::string, std::vector<std::string>> allassign = sessionControlBankAccount->selectBeneficiary();
		std::map<std::string, std::vector<std::string>> assigninfo = sessionControlBankAccount->getDetails();
		unsigned totalNumberOfBankAccounts = bankAccount.size();
		unsigned accountSelection;
		std::string accountname;

		if (selectedRole == "Clerk") {
			if (selectedCommand == "Deposit Money") {
				std::string AccNo;
				std::string AccName;
				do
				{
					std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					std::cout << "  Account No: ";
					std::getline(std::cin, AccNo);
					std::cout << " Account Name: ";
					std::getline(std::cin, AccName);
					if (AccNo != "" && AccName != "")
					{
						_logger << "Validation successfull for \"" + AccNo + "\" with name \"" + AccName + "\"";
						break;
					}
					std::cout << "** Validation failed\n";
					_logger << "No such account: \"" + AccNo + "\" with name \"" + AccName + "\"";
				} while (true);

				std::string DepositAmount;
				std::cout << "Enter deposit Amount \n";
				std::cin >> DepositAmount;

				_logger << "Deposit Successful";

			}

			else if (selectedCommand == "Open Account") {
				unsigned AccType;
				for (unsigned int i = 0; i < totalNumberOfBankAccounts; i++)
				{
					std::cout << std::setw(2) << i << " - " << bankAccount[i][5]  << "\n";
				}
				std::cout << "  Account Type (0-" << allassign[accountidentity].size() - 1 << "): ";
				std::cin >> AccType;
				unsigned i = 0;
				do
				{
					std::string answer;
					std::cout << assigninfo["100001"][i] << "\n";
					std::cin >> answer;
					i = i + 1;

				} while (i < assigninfo["100001"].size());
				std::string Account_Number = "100005";
				_logger << "Account with number \"" + Account_Number + "\" created";
			}


		}
	
		if (selectedRole == "Customer") {
			if (selectedCommand == "Transfer Money") {

				accountSelection = 0;
				std::string selectedAccount = bankAccount[accountSelection][0];
			//accountidentity = selectedAccount;
				accountidentity = "100001";

				accountname = bankAccount[accountSelection][1];
				std::cout << "  Select from the following beneficiaries: \n"; 
				unsigned selectedassign;
				for (unsigned int i = 0; i < allassign[accountidentity].size(); i++)
				{
					std::cout << std::setw(2) << i << " - " << allassign[accountidentity][i] << "\n";
				}
				std::cout << "  Destination Account (0-" << allassign[accountidentity].size() - 1 << "): ";
				std::cin >> selectedassign;
			

				_logger << "Selected account \"" + selectedAccount + "\" chosen";
				char Response;
				char Amount;
				std::cout << "Account No, Account Name \n";
				std::cout << bankAccount[accountSelection][0] + ", " + bankAccount[accountSelection][1];
				std::cout << "\n Do you want to transfer money to the above Account(Y|N): ";
				std::cin >> Response;

				if (Response == 'Y') {
					std::cout << "\n Enter Transfer Amount: ";
					std::cin >> Amount;
					
				}
				std::cout << "\n Confirm transfer of  \"" + Amount;

				std::string name = username;
				std::string bankaccountid = selectedAccount;
				std::string instructor = bankAccount[accountSelection][2];
				std::string schedule = bankAccount[accountSelection][3];
				std::string price = bankAccount[accountSelection][4];

				_logger << " Transfer Successful";
			}
			else if (selectedCommand == "Edit Profile")
			
			{
				unsigned selectedassign;
				std::string newVal;
				selectedassign = 1;
				accountidentity = "100001";

				for (unsigned int i = 0; i < assigninfo[accountidentity].size(); i++)
				{
					std::cout << std::setw(2) << i << " - " << assigninfo[accountidentity][i] << bankAccount[0][i+1]<<"\n";
				}

				std::cout << "  Option (0-" << allassign[accountidentity].size() - 1 << "): ";
				std::cin >> selectedassign;
				std::string benef = assigninfo[accountidentity][selectedassign];
				_logger << "Selected Option \"" + benef + "\" chosen";
				std::string somevalue;
				getline(std::cin, somevalue);
				unsigned i = 0;
				std::cout << "Enter New Value:";
				std::cin >> newVal;
				_logger << "Profile updated successfully";
			}

		}


	}
}