#pragma once

#include <memory>
#include <string>
#include <vector>

#include "MaintainAccountsHandler.hpp"


namespace Domain::Banking
{


    class Accounts : public Domain::Banking::MaintainAccountsHandler
    {
    public:
        // Constructors
        using MaintainAccountsHandler::MaintainAccountsHandler;  // inherit constructors


        // Operations
        std::vector<std::vector<std::string>> getAccountInfo() override;
        std::map<std::string, std::vector<std::string>> selectAccount() override;
        //std::map<std::string, std::vector<std::string>> getAssignment() override;
      



        ~Accounts() noexcept override;
    }; // class Courses


    /*****************************************************************************
    ** Inline implementations
    ******************************************************************************/
    inline Accounts::~Accounts() noexcept
    {}



    inline std::vector<std::vector<std::string>> Accounts::getAccountInfo()
    {
        return { {"1000000","Rutali DB", "Savings Account","1000"} , {"1000001","Ashu K", "Checking Account","5000"}, {"1000002","Ashu K", "Savings Account","10000"} };
    }

    inline std::map<std::string, std::vector<std::string>> Accounts::selectAccount()
    {
        std::map<std::string, std::vector<std::string>> AssignAccount;
        AssignAccount["Savings Account"] = { "Deposit Money", "Withdraw Money", "Transfer Money" , "Invest Money" };
        AssignAccount["Checking Account"] = { "Deposit Money", "Withdraw Money", "Transfer Money" };
        
        return AssignAccount;
    }





}  // namespace Domain::Banking
