#pragma once

#include <memory>
#include <string>
#include <vector>

#include "MaintainCoursesHandler.hpp"


namespace Domain::Banking
{
	
	
  class Courses : public Domain::Banking::MaintainCoursesHandler
  {
    public:
      // Constructors
      using MaintainCoursesHandler::MaintainCoursesHandler;  // inherit constructors
	  

      // Operations
	  std::vector<std::vector<std::string>> getCourses() override;
	  std::map<std::string, std::vector<std::string>> selectAssignment() override;
	  std::map<std::string, std::vector<std::string>> getAssignment() override;

     ~Courses() noexcept override;
  }; // class Courses


  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline Courses::~Courses() noexcept
  {}
  
  
  
  inline std::vector<std::vector<std::string>> Courses::getCourses()
  {
    
    return { {"Savings Account", "software design and architecture", "Prashant", "Tu-Th 3:00-4:50", "$2400", "Assignment 2"}, {"Checking Account", "modern software management", "Prashant", "Sa-Su 3:00-4:50", "$2400", "Assignment 3"} /*, {"CPSC 103", "software measuement", "Prashant", "M-W 5:30-7:00", "$2400", "Assignment 4"}, {"CPSC 104", "software verification and validation", "Prashant", "Tu-Th 5:00-6:30", "$2400", "Assignment 5"} */};
  }
  
  inline std::map<std::string, std::vector<std::string>> Courses::selectAssignment()
  {
	  std::map<std::string, std::vector<std::string>> AssignCourse;
	  AssignCourse["CPSC 462"] = {"Assignment 1", "Assignment 2"};
	  AssignCourse["CPSC 101"] = {"Assignment 2", "Assignment 3"};
	  AssignCourse["CPSC 102"] = {"Assignment 4", "Assignment 5"};
	  AssignCourse["CPSC 103"] = {"Assignment 4", "Assignment 5"};
	  return AssignCourse;
  }
  
  inline std::map<std::string, std::vector<std::string>> Courses::getAssignment()
  {
	  std::map<std::string, std::vector<std::string>> Assign;
	  Assign["Assignment 1"] = {{"What is the most important thing to learn from this class: "}, {"What is a fully dressed use case: "}, {"What is OOA/OOD: "}};
	  Assign["Assignment 2"] = {{"What is software design and archiecture: "}, {"What is the importance of use case diagram: "}, {"What are design principles: "}};
	  Assign["Assignment 3"] = {{"What is a baseline: "}, {"What is project scope statement: "}, {"What is PMO: "}};
	  Assign["Assignment 4"] = {{"What is the most important thing to learn from this class: "}, {"What is software design and archiecture: "}, {"What is PMO: "}};
	  Assign["Assignment 5"] = {{"What is software design and archiecture: "}, {"What is a fully dressed use case: "}, {"What is a baseline: "}};
    return Assign;
  }


}  // namespace Domain::Banking
