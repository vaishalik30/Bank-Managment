#pragma once

#include <memory>
#include <string>
#include <vector>

#include "Session.hpp"


namespace Domain::Banking
{
  class DeanSession : public Domain::Banking::SessionHandler
  {
    public:
      using SessionHandler::SessionHandler;  // inherit constructors

      // Operations
      std::vector<std::string> getCommands() override;  // retrieves the list of actions (commands)
	  // std::vector<std::string> getCourses() override;


      // Destructor
      // Pure virtual destructor helps force the class to be abstract, but must still be implemented
     ~DeanSession() noexcept override;
  }; // class DeanSession





  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline DeanSession::~DeanSession() noexcept
  {}


  inline std::vector<std::string> DeanSession::getCommands()
  {
    return { "Add Stream", "Add Degree" };
  }

} // namespace Domain::Banking
