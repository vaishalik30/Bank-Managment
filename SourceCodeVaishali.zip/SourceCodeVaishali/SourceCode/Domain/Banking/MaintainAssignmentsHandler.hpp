#pragma once

#include <memory>  // unique_ptr
#include <string>
#include <vector>

namespace Domain::Banking
{
  // Library Package within the Domain Layer Abstract class
  
  // struct CourseDetails
	// {
    // std::string               courseId;
    // std::string               courseName;
	// std::string               instructor;
	// std::string               schedule;
	// std::string               price;
	// };
  
  class MaintainAssignmentsHandler
  {
    public:
      // Constructors
      MaintainAssignmentsHandler()                                          = default;        // default ctor
      MaintainAssignmentsHandler( const MaintainAssignmentsHandler &  original )  = default;        // copy ctor
      MaintainAssignmentsHandler(       MaintainAssignmentsHandler && original )  = default;        // move ctor

      // Operations
	  virtual std::map<std::string, std::vector<std::string>> getAssignment() = 0;  // retrieves the list of actions (commands)
	  
	  // static std::unique_ptr<MaintainAssignmentsHandler> createCommand( const std::string & command );

      // Destructor
      // Pure virtual destructor helps force the class to be abstract, but must still be implemented
      virtual ~MaintainAssignmentsHandler() noexcept = 0;

    protected:
      // Copy assignment operators, protected to prevent mix derived-type assignments
      MaintainAssignmentsHandler & operator=( const MaintainAssignmentsHandler &  rhs ) = default;  // copy assignment
      MaintainAssignmentsHandler & operator=(       MaintainAssignmentsHandler && rhs ) = default;  // move assignment

  };    // class MaintainAssignmentsHandler





  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline MaintainAssignmentsHandler::~MaintainAssignmentsHandler() noexcept
  {}


} // namespace Domain::Banking
