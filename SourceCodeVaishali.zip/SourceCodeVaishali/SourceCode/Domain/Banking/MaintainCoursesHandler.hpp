#pragma once

#include <memory>  // unique_ptr
#include <string>
#include <vector>
#include <map>

namespace Domain::Banking
{

  
  class MaintainCoursesHandler
  {
    public:
      // Constructors
      MaintainCoursesHandler()                                          = default;        // default ctor
      MaintainCoursesHandler( const MaintainCoursesHandler &  original )  = default;        // copy ctor
      MaintainCoursesHandler(       MaintainCoursesHandler && original )  = default;        // move ctor

      // Operations
	  virtual std::vector<std::vector<std::string>> getCourses() = 0;  // retrieves the list of actions (commands)
	  virtual std::map<std::string, std::vector<std::string>> selectAssignment() = 0; 
	  virtual std::map<std::string, std::vector<std::string>> getAssignment() = 0;  // retrieves the list of actions (commands)
	  
	  static std::unique_ptr<MaintainCoursesHandler> selectCommand( const std::string & command );

      // Destructor
      // Pure virtual destructor helps force the class to be abstract, but must still be implemented
      virtual ~MaintainCoursesHandler() noexcept = 0;

    protected:
      // Copy assignment operators, protected to prevent mix derived-type assignments
      MaintainCoursesHandler & operator=( const MaintainCoursesHandler &  rhs ) = default;  // copy assignment
      MaintainCoursesHandler & operator=(       MaintainCoursesHandler && rhs ) = default;  // move assignment

  };    // class MaintainCoursesHandler





  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline MaintainCoursesHandler::~MaintainCoursesHandler() noexcept
  {}


} // namespace Domain::Banking
