#pragma once

#include <memory>
#include <string>
#include <vector>

#include "Session.hpp"


namespace Domain::Banking
{
  class StudentSession : public Domain::Banking::SessionHandler
  {
    public:
      using SessionHandler::SessionHandler;  // inherit constructors

      // Operations
      std::vector<std::string> getCommands() override;  // retrieves the list of actions (commands)
	  
	  //std::vector<std::string> getCourses() override;

      // Destructor
      // Pure virtual destructor helps force the class to be abstract, but must still be implemented
     ~StudentSession() noexcept override;
  }; // class StudentSession





  /*****************************************************************************
  ** Inline implementations
  ******************************************************************************/
  inline StudentSession::~StudentSession() noexcept
  {}


  inline std::vector<std::string> StudentSession::getCommands()
  {
    return { "Edit Profile", "Transfer Money", "Take Exam", "Submit Assignment", "View Results" };
  }
  
} // namespace Domain::Banking
