#include <iomanip>                                                                    // setw()
#include <iostream>                                                                   // streamsize
#include <limits>                                                                     // numeric_limits
#include <memory>                                                                     // unique_ptr, make_unique<>()
#include <string>                                                                     // string, getline()
#include <vector>
#include <fstream>

#include "../Domain/AccountManagement/UserAccounts.hpp"                                  // Include for now - will replace next increment
#include "../Domain/Banking/Courses.hpp"                                                   // Include for now - will replace next increment
#include "../Domain/Banking/Session.hpp"

#include "../TechnicalServices/Logging/LoggerHandler.hpp"
#include "../TechnicalServices/Logging/SimpleLogger.hpp"                                 // Include for now - will replace next increment
#include "../TechnicalServices/Persistence/SimpleDB.hpp"                                 // Include for now - will replace next increment
#include "SimpleUI.hpp"
#include "../../readfile.cpp"

namespace UI
{
	// Default constructor
	SimpleUI::SimpleUI()
		: _accounts(std::make_unique<Domain::AccountManagement::UserAccounts>()),   // will replace these factory calls with abstract factory calls in the next increment
		_bookHandler(std::make_unique<Domain::Banking::Courses>()),   // will replace these factory calls with abstract factory calls in the next increment
		_loggerPtr(std::make_unique<TechnicalServices::Logging::SimpleLogger>()),   // will replace these factory calls with abstract factory calls in the next increment
		_persistentData(std::make_unique<TechnicalServices::Persistence::SimpleDB>())    // will replace these factory calls with abstract factory calls in the next increment
	{
		_logger << "Simple UI being used and has been successfully initialized";
	}


	// Destructor
	SimpleUI::~SimpleUI() noexcept
	{
		_logger << "Simple UI shutdown successfully";
	}



	// Operations
	void SimpleUI::launch()
	{
		// 1) Fetch Role legal value list

		std::vector<std::string> roleLegalValues = _persistentData->findRoles();
		std::string selectedRole;
		std::string selectedCommand;
		std::string username;
		std::string courseidentity;

		// 2) Present login screen to user and get username, password, and valid role
		do
		{
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

			std::string userName;
			std::cout << "  name: ";
			std::getline(std::cin, userName);

			std::string passPhrase;
			std::cout << "  pass phrase: ";
			std::getline(std::cin, passPhrase);

			unsigned menuSelection;
			do
			{
				for (unsigned i = 0; i != roleLegalValues.size(); ++i)   std::cout << std::setw(2) << i << " - " << roleLegalValues[i] << '\n';
				std::cout << "  role (0-" << roleLegalValues.size() - 1 << "): ";
				std::cin >> menuSelection;
			} while (menuSelection >= roleLegalValues.size());

			selectedRole = roleLegalValues[menuSelection];
			username = userName;


			// 3) Validate user is authorized for this role
			if (_accounts->isAuthenticated({ userName, passPhrase, {selectedRole} }))
			{
				_logger << "Login Successful for \"" + userName + "\" as role \"" + selectedRole + "\"";
				break;
			}

			std::cout << "** Login failed\n";
			_logger << "Login failure for \"" + userName + "\" as role \"" + selectedRole + "\"";

		} while (true);



		// 4) Fetch functionality options for this role
		std::unique_ptr<Domain::Banking::SessionHandler> sessionControl = Domain::Banking::SessionHandler::createSession(selectedRole);

		std::vector<std::string> commands = sessionControl->getCommands();
		unsigned totalNumberOfCommands = commands.size();
		unsigned menuSelection;
		do
		{
			for (unsigned i = 0; i != commands.size(); ++i)   std::cout << std::setw(2) << i << " - " << commands[i] << '\n';
			std::cout << "  role (0-" << commands.size() - 1 << "): ";
			std::cin >> menuSelection;
		} while (menuSelection >= totalNumberOfCommands);

		selectedCommand = commands[menuSelection];
		_logger << "Selected command \"" + selectedCommand + "\" chosen";



		// 4) Fetch functionality options for this role
		std::unique_ptr<Domain::Banking::MaintainCoursesHandler> sessionControlCourse = Domain::Banking::MaintainCoursesHandler::selectCommand(selectedCommand);

		std::vector<std::vector<std::string>> courses = sessionControlCourse->getCourses();
		std::map<std::string, std::vector<std::string>> allassign = sessionControlCourse->selectAssignment();
		std::map<std::string, std::vector<std::string>> assigninfo = sessionControlCourse->getAssignment();
		unsigned totalNumberOfCourses = courses.size();
		unsigned courseSelection;
		std::string coursename;

		if (selectedRole == "Clerk") {
			if (selectedCommand == "Manage Funds") {
				std::string AccNo;
				std::string AccName;
				do
				{
					std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');


					std::cout << "  Account No: ";
					std::getline(std::cin, AccNo);


					std::cout << " Account Name: ";
					std::getline(std::cin, AccName);


					if (AccNo != "" && AccName != "")
					{
						_logger << "Validation successfull for \"" + AccNo + "\" with name \"" + AccName + "\"";
						break;
					}

					std::cout << "** Validation failed\n";
					_logger << "No such account: \"" + AccNo + "\" with name \"" + AccName + "\"";

				} while (true);

				std::string DepositAmount;

				std::cout << "Enter deposit Amount \n";

				//std::cout << students[i] << ":";
				std::cin >> DepositAmount;
				std::ofstream accountFile;
				accountFile.open("grades.csv", std::ios_base::app);
				accountFile << AccNo + ", " + AccName + ", " + DepositAmount + "\n";
				accountFile.close();



				_logger << "Deposit Successful";


			}
			// Creating an object of CSVWriter
			CSVReader reader("enrollment.csv");
			// Get the data from CSV File
			std::vector<std::vector<std::string> > dataList = reader.getData();
			// Print the content of row by row on screen
			std::vector<std::string> students;


			for (std::vector<std::string> vec : dataList)
			{
				if (vec[1] == " " + courseidentity) {
					students.push_back(vec[0]);
				}
			}

			/*
			std::string gradez;
			unsigned i = 0;
			std::cout << "Enter deposit Amount \n";
			do
			{
				//std::cout << students[i] << ":";
				std::cin >> gradez;
				std::ofstream mygradesfile;
				mygradesfile.open("grades.csv", std::ios_base::app);
				mygradesfile << students[i] + ", " + courseidentity + ", " + gradez + "\n";
				mygradesfile.close();
				i = i + 1;
			} while (i < students.size());

			_logger << "Deposit Successful";
		}*/



	


			if (selectedRole == "Student") {

				do
				{
					for (unsigned i = 0; i != courses.size(); ++i)   std::cout << std::setw(2) << i << " - " << courses[i][0] << '\n';
					// +", "+courses[i][1]+", "+courses[i][2] +", "+courses[i][3] +", "+courses[i][4] <<
					std::cout << "  course (0-" << courses.size() - 1 << "): ";
					std::cin >> courseSelection;
				} while (courseSelection >= totalNumberOfCourses);

				std::string selectedCourse = courses[courseSelection][0];
				courseidentity = selectedCourse;
				coursename = courses[courseSelection][1];
				_logger << "Selected course \"" + selectedCourse + "\" chosen";


				if (selectedCommand == "Enroll in Course") {
					char Response;
					std::cout << "Course Id, Course Name, Instructor, Schedule, Price \n \n";
					std::cout << courses[courseSelection][0] + ", " + courses[courseSelection][1] + ", " + courses[courseSelection][2] + ", " + courses[courseSelection][3] + ", " + courses[courseSelection][4];
					std::cout << "\n Do you want to enroll to this course(Y|N): ";
					std::cin >> Response;

					if (Response == 'Y') {
						_logger << courses[courseSelection][1] + " is added to your courses";
					}


					std::string name = username;
					std::string courseid = selectedCourse;
					// std::string coursename = courses[courseSelection][1];
					std::string instructor = courses[courseSelection][2];
					std::string schedule = courses[courseSelection][3];
					std::string price = courses[courseSelection][4];
					std::ofstream myfile;
					myfile.open("enrollment.csv", std::ios_base::app);
					myfile << name + ", " + courseid + ", " + coursename + ", " + instructor + ", " + schedule + ", " + price + "\n";
					myfile.close();
				}
				if (selectedCommand == "Submit Assignment")
				{
					unsigned selectedassign;
					for (unsigned int i = 0; i < allassign[courseidentity].size(); i++)
					{
						std::cout << std::setw(2) << i << " - " << allassign[courseidentity][i] << "\n";
					}
					std::cout << "  assignment (0-" << allassign[courseidentity].size() - 1 << "): ";
					std::cin >> selectedassign;
					std::string assignment = allassign[courseidentity][selectedassign];
					_logger << "Selected assignment \"" + assignment + "\" chosen";
					std::string somevalue;
					getline(std::cin, somevalue);
					unsigned i = 0;
					do
					{
						std::string answer;
						std::cout << assigninfo[assignment][i] << "\n";
						getline(std::cin, answer);
						std::ofstream assignmentfile;
						assignmentfile.open("assignment.csv", std::ios_base::app);
						assignmentfile << username + ", " + courseidentity + ", " + assignment + "," + assigninfo[assignment][i] + "," + answer + "\n";
						assignmentfile.close();
						i = i + 1;
					} while (i < assigninfo[assignment][0].size());
					_logger << "Assignment added successfully";
				}

			}

			/*
			else if(selectedRole == "Clerk"){



				// Creating an object of CSVWriter
				CSVReader reader("enrollment.csv");
				// Get the data from CSV File
				std::vector<std::vector<std::string> > dataList = reader.getData();
				// Print the content of row by row on screen
				std::vector<std::string> students;


				for(std::vector<std::string> vec : dataList)
				{
					if(vec[1] == " "+courseidentity){
						students.push_back(vec[0]);
					}
				}


				std::string gradez;
				unsigned i=0;
				std::cout << "Enter deposit Amount \n";
				do
					{
					 std::cout << students[i] << ":";
					std::cin >> gradez;
					std::ofstream mygradesfile;
					mygradesfile.open("grades.csv", std::ios_base::app);
					mygradesfile << students[i]+", "+courseidentity+", "+gradez+"\n";
					mygradesfile.close();
					i = i + 1;
					} while( i < students.size() );

				_logger << "Deposit Successful";
			}

			*/
		}

	}
}